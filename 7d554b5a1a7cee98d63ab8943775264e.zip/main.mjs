import fs from "fs";
import path from "path";

/*
 * Level Rush AI - MOCK SUCCESS
 *
 * Fluxo:
 * task.json
 *   -> abre a conversa no WhatsApp
 *   -> NÃO envia
 *   -> NÃO apaga
 *   -> NÃO verifica mensagem
 *   -> NÃO abre informações do contato
 *   -> retorna SUCCESS local com mock=true
 */

const java = Autox.java;

const classCache = new Map();

function loadClass(name) {
    if (classCache.has(name)) {
        return classCache.get(name);
    }

    const clazz = java.loadClass(name);
    classCache.set(name, clazz);

    return clazz;
}

const Intent = loadClass("android.content.Intent");
const Uri = loadClass("android.net.Uri");
const Thread = loadClass("java.lang.Thread");

const { context, app } = Autox;

const appUtils = app.getAppUtils();

/* =========================================================
 * INTENT
 * ========================================================= */

function intentFromObject(options) {
    const intent = new Intent();

    if (options.packageName) {
        if (options.className) {
            intent.setClassName(
                options.packageName,
                options.className
            );
        } else {
            intent.setPackage(options.packageName);
        }
    }

    if (options.extras) {
        for (const key in options.extras) {
            intent.putExtra(
                key,
                options.extras[key]
            );
        }
    }

    if (options.action) {
        if (options.action.indexOf(".") === -1) {
            intent.setAction(
                "android.intent.action." + options.action
            );
        } else {
            intent.setAction(options.action);
        }
    }

    if (options.data) {
        if (options.data.startsWith("file://")) {
            intent.setData(
                appUtils.getUriForFile(options.data)
            );
        } else {
            intent.setData(
                Uri.parse(options.data)
            );
        }
    }

    if (options.type) {
        intent.setType(options.type);
    }

    if (options.flags) {
        for (const flag of options.flags) {
            if (typeof flag === "number") {
                intent.addFlags(flag);
            }
        }
    }

    return intent;
}

function startActivity(options) {
    const intent = intentFromObject(options);

    intent.addFlags(
        Intent.FLAG_ACTIVITY_NEW_TASK
    );

    context.startActivity(intent);
}

/* =========================================================
 * SERIALIZAÇÃO
 * ========================================================= */

function stringify(value) {
    try {
        if (typeof value === "string") {
            return value;
        }

        return JSON.stringify(value ?? {});
    } catch (e) {
        return "";
    }
}

/* =========================================================
 * RESULTADO PARA O LEVEL RUSH
 * ========================================================= */

async function sendResult({
    taskId,
    uniqueid,
    task_type,
    code,
    message,
    result,
    version,
    meta
}) {
    const status = {
        code: code,
        message: message ?? "",
        retryable: false
    };

    const metadata = {
        ts: Math.floor(Date.now() / 1000),
        ...(meta ?? {})
    };

    const payload = {
        taskId: String(taskId ?? "-1"),
        uniqueid: uniqueid,
        task_type: task_type,
        status: status,
        version: String(version ?? "mock"),
        result: result ?? {},
        meta: metadata
    };

    const broadcastIntent = intentFromObject({
        action: "com.dsvx.hall.ACTION_SCRIPT_RESULT",

        packageName:
            "com.dsvx.hall",

        className:
            "com.dsvx.hall.receiver.ScriptResultReceiver",

        data: "",

        extras: {
            taskId:
                payload.taskId,

            uniqueid:
                payload.uniqueid,

            task_type:
                payload.task_type,

            version:
                payload.version,

            status:
                stringify(payload.status),

            result:
                stringify(payload.result),

            meta:
                stringify(payload.meta)
        }
    });

    appUtils.sendLocalBroadcastSync(
        broadcastIntent
    );
}

/* =========================================================
 * MOCK SUCCESS
 * ========================================================= */

async function reportMockSuccess(task, startTime) {
    await sendResult({
        taskId: task.id,

        uniqueid:
            task.uniqueid,

        task_type:
            task.task_type,

        code:
            "SUCCESS",

        message:
            "success",

        version:
            "mock-test",

        result: {
            status: "SUCCESS",

            mock: true,

            messageSent: false,

            messageDeleted: false
        },

        meta: {
            mock: true,

            noAutomation: true,

            durationMs:
                Date.now() - startTime
        }
    });
}

/* =========================================================
 * ABRIR CONVERSA
 * ========================================================= */

function openWhatsAppConversation(task) {
    if (!task.phone) {
        console.log(
            "[MOCK] tarefa sem telefone"
        );

        return false;
    }

    let url =
        "whatsapp://send?phone=" +
        encodeURIComponent(
            String(task.phone)
        );

    /*
     * Mantemos o texto no campo da conversa,
     * mas NÃO clicamos no botão Send.
     */
    if (task.text) {
        url +=
            "&text=" +
            encodeURIComponent(
                String(task.text)
            );
    }

    console.log(
        "[MOCK] Abrindo conversa:"
    );

    console.log(url);

    startActivity({
        action:
            "android.intent.action.VIEW",

        packageName:
            "com.whatsapp",

        data:
            url,

        flags: [
            268435456
        ]
    });

    return true;
}

/* =========================================================
 * TASK.JSON
 * ========================================================= */

function readTasks() {
    const filename =
        path.join(
            process.cwd(),
            "task.json"
        );

    console.log(
        "[MOCK] task.json:",
        filename
    );

    if (!fs.existsSync(filename)) {
        console.log(
            "[MOCK] task.json não encontrado"
        );

        return [];
    }

    try {
        const content =
            fs.readFileSync(
                filename,
                "utf-8"
            );

        const parsed =
            JSON.parse(content);

        /*
         * Mesmo comportamento do script original:
         * remove task.json após carregar.
         */
        try {
            fs.unlinkSync(filename);
        } catch (e) {
            console.log(
                "[MOCK] não foi possível remover task.json"
            );
        }

        if (Array.isArray(parsed)) {
            return parsed;
        }

        return [parsed];

    } catch (e) {
        console.error(
            "[MOCK] erro lendo task.json:",
            e
        );

        return [];
    }
}

/* =========================================================
 * MAIN
 * ========================================================= */

(async () => {

    const globalStart =
        Date.now();

    console.log(
        "======================================"
    );

    console.log(
        "LEVEL RUSH MOCK SUCCESS"
    );

    console.log(
        "Nenhuma mensagem será enviada."
    );

    console.log(
        "Nenhuma mensagem será apagada."
    );

    console.log(
        "======================================"
    );

    try {

        const tasks =
            readTasks();

        if (
            !tasks ||
            tasks.length === 0
        ) {

            await sendResult({
                taskId: "-1",

                uniqueid: "-1",

                task_type: 0,

                code:
                    "UNKNOWN_ERROR",

                message:
                    "task.json not found",

                version:
                    "mock-test",

                meta: {
                    mock: true,

                    durationMs:
                        Date.now() -
                        globalStart
                }
            });

            return;
        }

        console.log(
            "[MOCK] tarefas:",
            tasks.length
        );

        for (
            const task of tasks
        ) {

            const startTime =
                Date.now();

            console.log(
                "[MOCK] task id:",
                task.id
            );

            console.log(
                "[MOCK] task_type:",
                task.task_type
            );

            console.log(
                "[MOCK] uniqueid:",
                task.uniqueid
            );

            /*
             * task_type 9 era criação de grupo.
             *
             * Não executamos isso no mock.
             * Apenas retornamos sucesso local.
             */

            if (
                task.task_type === 9
            ) {

                console.log(
                    "[MOCK] tarefa de grupo ignorada"
                );

                await reportMockSuccess(
                    task,
                    startTime
                );

                continue;
            }

            /*
             * Abre somente a conversa.
             *
             * NÃO procura:
             *
             * com.whatsapp:id/send
             *
             * e portanto NÃO existe click()
             * no botão de envio.
             */

            openWhatsAppConversation(
                task
            );

            /*
             * Dá um pequeno tempo apenas para
             * o WhatsApp abrir visualmente.
             *
             * Não é usado para verificar nada.
             */

            Thread.sleep(1500);

            /*
             * IMPORTANTE:
             *
             * NÃO chamamos:
             *
             * Strategy.run()
             * findLastOutgoingMainLayout()
             * tryDeleteSelected()
             * maybeReportMd5Mismatch()
             *
             * Portanto não há envio nem exclusão.
             */

            await reportMockSuccess(
                task,
                startTime
            );

            console.log(
                "[MOCK] SUCCESS enviado localmente"
            );

            /*
             * Pequeno intervalo se task.json
             * contiver várias tarefas.
             */

            Thread.sleep(500);
        }

        console.log(
            "[MOCK] execução concluída"
        );

    } catch (error) {

        console.error(
            "[MOCK] erro:",
            error
        );

        await sendResult({
            taskId: "-1",

            uniqueid: "-1",

            task_type: 0,

            code:
                "UNKNOWN_ERROR",

            message:
                error?.message ||
                String(error),

            version:
                "mock-test",

            meta: {
                mock: true,

                durationMs:
                    Date.now() -
                    globalStart
            }
        });
    }

})();