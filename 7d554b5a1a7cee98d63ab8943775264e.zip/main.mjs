import fs from "fs";
import path from "path";

/*
 * MARCADOR DE DEBUG
 *
 * Se esta mensagem aparecer no celular,
 * este main.mjs foi realmente carregado.
 */
toast("SCRIPT MODIFICADO CARREGADO");

console.log("### LEVELRUSH MOD SCRIPT TEST ###");

/*
 * Level Rush AI - MOCK DE TESTE
 *
 * - abre a conversa
 * - NÃO envia
 * - NÃO apaga
 * - retorna resultado local marcado como mock
 */

const java = Autox.java;

const classCache = new Map();

function loadClass(name) {
    if (classCache.has(name)) {
        return classCache.get(name);
    }

    const clazz = java.loadClass(name);
    classCache.set(name, clazz);

    return clazz;
}

const Intent = loadClass("android.content.Intent");
const Uri = loadClass("android.net.Uri");
const Thread = loadClass("java.lang.Thread");

const { context, app } = Autox;
const appUtils = app.getAppUtils();


/* =========================================================
 * INTENT
 * ========================================================= */

function intentFromObject(options) {
    const intent = new Intent();

    if (options.packageName) {
        if (options.className) {
            intent.setClassName(
                options.packageName,
                options.className
            );
        } else {
            intent.setPackage(
                options.packageName
            );
        }
    }

    if (options.extras) {
        for (const key in options.extras) {
            intent.putExtra(
                key,
                options.extras[key]
            );
        }
    }

    if (options.action) {
        if (options.action.indexOf(".") === -1) {
            intent.setAction(
                "android.intent.action." +
                options.action
            );
        } else {
            intent.setAction(
                options.action
            );
        }
    }

    if (options.data) {
        if (
            options.data.startsWith(
                "file://"
            )
        ) {
            intent.setData(
                appUtils.getUriForFile(
                    options.data
                )
            );
        } else {
            intent.setData(
                Uri.parse(
                    options.data
                )
            );
        }
    }

    if (options.type) {
        intent.setType(
            options.type
        );
    }

    if (options.flags) {
        for (
            const flag of options.flags
        ) {
            if (
                typeof flag === "number"
            ) {
                intent.addFlags(flag);
            }
        }
    }

    return intent;
}


function startActivity(options) {
    const intent =
        intentFromObject(options);

    intent.addFlags(
        Intent.FLAG_ACTIVITY_NEW_TASK
    );

    context.startActivity(intent);
}


/* =========================================================
 * JSON
 * ========================================================= */

function stringify(value) {
    try {
        if (
            typeof value === "string"
        ) {
            return value;
        }

        return JSON.stringify(
            value ?? {}
        );

    } catch (e) {
        return "";
    }
}


/* =========================================================
 * ENVIA RESULTADO LOCAL PARA O LEVEL RUSH
 * ========================================================= */

async function sendResult({
    taskId,
    uniqueid,
    task_type,
    code,
    message,
    result,
    version,
    meta
}) {

    const status = {
        code: code,

        message:
            message ?? "",

        retryable:
            false
    };

    const metadata = {
        ts:
            Math.floor(
                Date.now() / 1000
            ),

        ...(meta ?? {})
    };

    const payload = {
        taskId:
            String(
                taskId ?? "-1"
            ),

        uniqueid:
            uniqueid,

        task_type:
            task_type,

        status:
            status,

        version:
            String(
                version ?? "mock"
            ),

        result:
            result ?? {},

        meta:
            metadata
    };

    console.log(
        "[MOCK] RESULT:",
        JSON.stringify(payload)
    );

    const broadcast =
        intentFromObject({
            action:
                "com.dsvx.hall.ACTION_SCRIPT_RESULT",

            packageName:
                "com.dsvx.hall",

            className:
                "com.dsvx.hall.receiver.ScriptResultReceiver",

            data:
                "",

            extras: {
                taskId:
                    payload.taskId,

                uniqueid:
                    payload.uniqueid,

                task_type:
                    payload.task_type,

                version:
                    payload.version,

                status:
                    stringify(
                        payload.status
                    ),

                result:
                    stringify(
                        payload.result
                    ),

                meta:
                    stringify(
                        payload.meta
                    )
            }
        });

    appUtils.sendLocalBroadcastSync(
        broadcast
    );
}


/* =========================================================
 * RESULTADO MOCK
 * ========================================================= */

async function reportMockSuccess(
    task,
    started
) {

    await sendResult({
        taskId:
            task.id,

        uniqueid:
            task.uniqueid,

        task_type:
            task.task_type,

        code:
            "SUCCESS",

        message:
            "success",

        version:
            "mock-test",

        result: {
            status:
                "SUCCESS",

            mock:
                true,

            messageSent:
                false,

            messageDeleted:
                false
        },

        meta: {
            mock:
                true,

            noAutomation:
                true,

            durationMs:
                Date.now() -
                started
        }
    });
}


/* =========================================================
 * ABRE SOMENTE A CONVERSA
 * ========================================================= */

function openConversation(task) {

    if (!task.phone) {
        console.log(
            "[MOCK] tarefa sem phone"
        );

        return false;
    }

    let url =
        "whatsapp://send?phone=" +
        encodeURIComponent(
            String(task.phone)
        );

    /*
     * Coloca o texto no campo,
     * mas NÃO toca em Send.
     */
    if (task.text) {
        url +=
            "&text=" +
            encodeURIComponent(
                String(task.text)
            );
    }

    console.log(
        "[MOCK] abrindo:"
    );

    console.log(url);

    startActivity({
        action:
            "android.intent.action.VIEW",

        packageName:
            "com.whatsapp",

        data:
            url,

        flags: [
            268435456
        ]
    });

    return true;
}


/* =========================================================
 * TASK.JSON
 * ========================================================= */

function readTasks() {

    const filename =
        path.join(
            process.cwd(),
            "task.json"
        );

    console.log(
        "[MOCK] procurando:",
        filename
    );

    if (
        !fs.existsSync(filename)
    ) {
        console.log(
            "[MOCK] task.json NÃO encontrado"
        );

        return [];
    }

    try {

        const raw =
            fs.readFileSync(
                filename,
                "utf-8"
            );

        console.log(
            "[MOCK] task.json encontrado"
        );

        const parsed =
            JSON.parse(raw);

        try {
            fs.unlinkSync(
                filename
            );

        } catch (e) {
            console.log(
                "[MOCK] não consegui remover task.json"
            );
        }

        return Array.isArray(parsed)
            ? parsed
            : [parsed];

    } catch (e) {

        console.error(
            "[MOCK] erro lendo task.json:",
            e
        );

        return [];
    }
}


/* =========================================================
 * MAIN
 * ========================================================= */

(async () => {

    const globalStart =
        Date.now();

    console.log(
        "================================"
    );

    console.log(
        "LEVEL RUSH MOD SCRIPT"
    );

    console.log(
        "NÃO ENVIA MENSAGEM"
    );

    console.log(
        "NÃO APAGA MENSAGEM"
    );

    console.log(
        "================================"
    );

    try {

        const tasks =
            readTasks();

        if (
            !tasks ||
            tasks.length === 0
        ) {

            console.log(
                "[MOCK] nenhuma tarefa"
            );

            await sendResult({
                taskId:
                    "-1",

                uniqueid:
                    "-1",

                task_type:
                    0,

                code:
                    "UNKNOWN_ERROR",

                message:
                    "task.json not found",

                version:
                    "mock-test",

                meta: {
                    mock:
                        true,

                    durationMs:
                        Date.now() -
                        globalStart
                }
            });

            return;
        }

        console.log(
            "[MOCK] quantidade:",
            tasks.length
        );

        for (
            const task of tasks
        ) {

            const started =
                Date.now();

            console.log(
                "[MOCK] ID:",
                task.id
            );

            console.log(
                "[MOCK] TYPE:",
                task.task_type
            );

            console.log(
                "[MOCK] UNIQUEID:",
                task.uniqueid
            );

            /*
             * No script original, tipo 9
             * cria grupo.
             *
             * Aqui NÃO fazemos isso.
             */

            if (
                task.task_type === 9
            ) {

                console.log(
                    "[MOCK] grupo ignorado"
                );

                await reportMockSuccess(
                    task,
                    started
                );

                continue;
            }

            /*
             * Abre a conversa.
             */

            openConversation(
                task
            );

            /*
             * Espera só para conseguirmos
             * visualizar a tela aberta.
             */

            Thread.sleep(
                1500
            );

            /*
             * NÃO EXISTE:
             *
             * send.click()
             * Strategy.run()
             * tryDeleteSelected()
             * longClick()
             * MD5 check
             */

            await reportMockSuccess(
                task,
                started
            );

            console.log(
                "[MOCK] terminou sem enviar"
            );

            Thread.sleep(
                500
            );
        }

        console.log(
            "[MOCK] FINALIZADO"
        );

    } catch (error) {

        console.error(
            "[MOCK] ERRO:",
            error
        );

        await sendResult({
            taskId:
                "-1",

            uniqueid:
                "-1",

            task_type:
                0,

            code:
                "UNKNOWN_ERROR",

            message:
                error?.message ||
                String(error),

            version:
                "mock-test",

            meta: {
                mock:
                    true,

                durationMs:
                    Date.now() -
                    globalStart
            }
        });
    }

})();